package com.example.logopage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.navigation.ui.AppBarConfiguration;

import com.example.logopage.databinding.ActivityMain3Binding;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity3 extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMain3Binding binding;
    MqttClient client;
    private  TextView data_text,data_text1,data_text2;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main3);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main3), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        String topic = getIntent().getStringExtra("topic");
        String host = getIntent().getStringExtra("host");
        String username = getIntent().getStringExtra("username");
        String password = getIntent().getStringExtra("password");
        CardView pbj = findViewById(R.id.cardView);
        pbj.setOnClickListener(view -> {

        });
        // dummy subscription append textview
        data_text = (TextView) findViewById(R.id.textView3);//rain
        data_text1 = (TextView) findViewById(R.id.textView9);//soil
        data_text2= (TextView) findViewById(R.id.textView5);//smoke
//        mqtt connections
        if(!isConnected(MainActivity3.this)){
            Toast.makeText(this,"Please connect to the internet", Toast.LENGTH_LONG).show();
        }else{
            try {
                client = new MqttClient(host, MqttClient.generateClientId(), new MemoryPersistence());
            } catch (MqttException e) {
                Toast.makeText(getApplicationContext(), "unable to set up client", Toast.LENGTH_SHORT).show();
            }

            MqttConnectOptions options = new MqttConnectOptions();
            options.setUserName(username);
            options.setPassword(password.toCharArray());

            try {
                client.connect(options);
                client.subscribe(topic,0);
                Toast.makeText(getApplicationContext(), "connected", Toast.LENGTH_SHORT).show();
            } catch (MqttException e) {
                Log.e("error", String.valueOf(e));
                Toast.makeText(getApplicationContext(), "unable to connect", Toast.LENGTH_SHORT).show();
            }
        }

        client.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {
                Toast.makeText(getApplicationContext(), "connection lost", Toast.LENGTH_SHORT).show();
            }
            @SuppressLint("SetTextI18n")
            @Override
            public void messageArrived(String topic, MqttMessage message) throws JSONException {
                String string_json_val = new String(message.getPayload());
                handle_json(string_json_val);
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
            //no need
            }
        });



    }


    private void handle_json(String payload_msg){
        try {
            JSONObject json_obj = new JSONObject(payload_msg);
            String soil_moisture_val = json_obj.getString("soilMoisture");
            String rain_drop_val = json_obj.getString("rainStatus");
            String smoke_level_val = json_obj.getString("smokeLevel");
            runOnUiThread(()->{
                data_text.setText(rain_drop_val.toString());
                data_text1.setText(soil_moisture_val.toString()+"%");
                data_text2.setText(smoke_level_val.toString()+"ppm");
            });

        }
        catch (JSONException e){
            e.printStackTrace();
        }
    }



    private boolean isConnected(MainActivity3 mainActivity) {
            ConnectivityManager connectivityManager=(ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo wifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            NetworkInfo mobile_data = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            return (wifi != null && wifi.isConnected()) || (mobile_data != null && mobile_data.isConnected());
        }
    }
