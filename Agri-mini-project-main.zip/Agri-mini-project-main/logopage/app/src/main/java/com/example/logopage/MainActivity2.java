package com.example.logopage;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.eclipse.paho.client.mqttv3.MqttClient;

public class MainActivity2 extends AppCompatActivity {
    MqttClient client;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main2), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        TextView topic = (TextView) findViewById(R.id.topic);
        TextView host = (TextView) findViewById(R.id.host);
        TextView username = (TextView) findViewById(R.id.username);
        TextView password = (TextView) findViewById(R.id.password);

        Button buttonToThird = (Button) findViewById(R.id.submit_btn);
//        btn_submit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////                Intent obj = new Intent(MainActivity2.this,MainActivity3.class);
//
////                startActivity(obj);
////                finish();
//                runOnUiThread(() -> {
//                    Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
//                    intent.putExtra("topic",topic.toString());
//                    intent.putExtra("host",host.toString());
//                    intent.putExtra("username",username.toString());
//                    intent.putExtra("password",password.toString());
//                    startActivity(intent);
//                });
//            }
//        });

        buttonToThird.setOnClickListener(view -> {
            String topic_str = topic.getText().toString().trim();
            String host_str = host.getText().toString().trim();
            String username_str = username.getText().toString().trim();
            String password_str = password.getText().toString().trim();
            //Toast.makeText(this, "topic data is:\t"+topic_str, Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
            intent.putExtra("topic",topic_str);
            intent.putExtra("host",host_str);
            intent.putExtra("username",username_str);
            intent.putExtra("password",password_str);
            startActivity(intent);
        });

    }


}